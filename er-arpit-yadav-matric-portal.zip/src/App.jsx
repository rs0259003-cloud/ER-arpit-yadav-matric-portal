import React, { useState, useEffect } from 'react';
import { 
  BookOpen, Clock, Award, CheckCircle, XCircle, User, 
  BarChart2, ShieldCheck, Trophy, RotateCcw, ArrowRight, ArrowLeft, 
  Plus, Trash2, Key, Download, HelpCircle, LogIn, LogOut, Check, ChevronRight, Menu, X, Smartphone
} from 'lucide-react';

const INITIAL_SUBJECTS = [
  { id: 'sci', name: 'विज्ञान (Science)', icon: '🧪', count: 20, color: 'from-blue-600 to-indigo-700' },
  { id: 'math', name: 'गणित (Mathematics)', icon: '📐', count: 15, color: 'from-emerald-600 to-teal-700' },
  { id: 'sst', name: 'सामाजिक विज्ञान (Social Science)', icon: '🌍', count: 20, color: 'from-amber-600 to-orange-700' },
  { id: 'hin', name: 'हिंदी (Hindi)', icon: '📚', count: 15, color: 'from-rose-600 to-red-700' },
  { id: 'sans', name: 'संस्कृत (Sanskrit)', icon: '🕉️', count: 10, color: 'from-purple-600 to-violet-700' },
  { id: 'eng', name: 'English', icon: '🔤', count: 10, color: 'from-cyan-600 to-blue-700' },
];

const INITIAL_QUESTIONS = {
  sci: [
    {
      id: 'sci_1',
      question: 'प्रकाश के परावर्तन के कितने नियम हैं?',
      options: ['1', '2', '3', '4'],
      correctAnswer: 1,
      explanation: 'प्रकाश के परावर्तन के मुख्य रूप से 2 नियम हैं: 1. आपतित किरण, परावर्तित किरण तथा आपतन बिंदु पर खींचा गया अभिलंब तीनों एक ही समतल में होते हैं। 2. आपतन कोण (i) सदैव परावर्तन कोण (r) के बराबर होता है।'
    },
    {
      id: 'sci_2',
      question: 'अम्ल का pH मान कितना होता है?',
      options: ['7 से कम', '7 से अधिक', '7 के बराबर', '14'],
      correctAnswer: 0,
      explanation: 'अम्लीय विलयन का pH मान सदैव 7 से कम होता है। उदासीन विलयन का 7 और क्षारीय विलयन का 7 से अधिक होता है।'
    },
    {
      id: 'sci_3',
      question: 'मानव नेत्र में किस प्रकार का लेंस पाया जाता है?',
      options: ['अवतल लेंस', 'उत्तर (उत्थल) लेंस', 'द्विफोकसी लेंस', 'बेलनाकार लेंस'],
      correctAnswer: 1,
      explanation: 'मानव नेत्र में उत्तल लेंस (Convex Lens) पाया जाता है जो एक प्राकृतिक जैविक लेंस है।'
    },
    {
      id: 'sci_4',
      question: 'विद्युत धारा का S.I. मात्रक क्या है?',
      options: ['वोल्ट', 'ओम', 'एम्पियर', 'वाट'],
      correctAnswer: 2,
      explanation: 'विद्युत धारा का SI मात्रक एम्पियर (A) होता है। इसे अमीटर (Ammeter) द्वारा मापा जाता है।'
    },
    {
      id: 'sci_5',
      question: 'पत्तियों में गैसों का आदान-प्रदान कहाँ होता है?',
      options: ['शिरा', 'रंध्र (Stomata)', 'मध्यशिरा', 'कोई नहीं'],
      correctAnswer: 1,
      explanation: 'पौधों की पत्तियों पर छोटे-छोटे छिद्र होते हैं जिन्हें रंध्र या स्टोमेटा कहते हैं, इन्हीं के माध्यम से गैसों का आदान-प्रदान होता है।'
    }
  ],
  math: [
    {
      id: 'm_1',
      question: 'द्विघात समीकरण ax² + bx + c = 0 का विविक्तकर (Discriminant, D) क्या होगा?',
      options: ['b² - 4ac', 'b² + 4ac', '-b ± √D', '4ac - b²'],
      correctAnswer: 0,
      explanation: 'द्विघात समीकरण का विविक्तकर D = b² - 4ac होता है।'
    },
    {
      id: 'm_2',
      question: 'यदि sin θ = 3/5 हो, तो cos θ का मान क्या होगा?',
      options: ['4/5', '5/3', '3/4', '5/4'],
      correctAnswer: 0,
      explanation: 'cos² θ = 1 - sin² θ = 1 - (3/5)² = 1 - 9/25 = 16/25. इसलिए cos θ = 4/5.'
    },
    {
      id: 'm_3',
      question: 'समानांतर श्रेणी (A.P.) 2, 7, 12, ... का 10वां पद क्या होगा?',
      options: ['47', '42', '52', '37'],
      correctAnswer: 0,
      explanation: 'प्रथम पद a = 2, सार्व अंतर d = 5. a₁₀ = a + 9d = 2 + 9(5) = 2 + 45 = 47.'
    }
  ],
  sst: [
    {
      id: 'sst_1',
      question: 'भारत में पहली जूट मिल कहाँ स्थापित की गई थी?',
      options: ['बंगाल (कोलकाता)', 'मुंबई', 'बिहार', 'गुजरात'],
      correctAnswer: 0,
      explanation: 'भारत की पहली जूट मिल 1855 में कोलकाता के पास रिशरा (बंगाल) में स्थापित की गई थी।'
    },
    {
      id: 'sst_2',
      question: 'यंग यूरोप की स्थापना किसने की थी?',
      options: ['काबूर ने', 'मेजिनी ने', 'बिस्मार्क ने', 'गैरीबाल्डी ने'],
      correctAnswer: 1,
      explanation: '1834 ई. में जोसेफ मेजिनी ने स्विट्जरलैंड के बर्न में "यंग यूरोप" नामक संगठन की स्थापना की थी।'
    }
  ],
  hin: [
    {
      id: 'h_1',
      question: 'श्रम विभाजन और जाति प्रथा के लेखक कौन हैं?',
      options: ['महात्मा गांधी', 'डॉ. भीमराव अंबेडकर', 'रामविलास शर्मा', 'नलीन विलोचन शर्मा'],
      correctAnswer: 1,
      explanation: 'श्रम विभाजन और जाति प्रथा निबंध के लेखक डॉ. भीमराव अंबेडकर हैं।'
    }
  ],
  sans: [
    {
      id: 'sn_1',
      question: 'मंगलम् पाठ कहाँ से संकलित है?',
      options: ['पुराण से', 'उपनिषद् से', 'वेद से', 'महाभारत से'],
      correctAnswer: 1,
      explanation: 'मंगलम् पाठ उपनिषद् से संकलित है, जिसमें वैदिक साहित्य के अंतिम भाग का दर्शन है।'
    }
  ],
  eng: [
    {
      id: 'en_1',
      question: 'Who wrote the lesson "The Pace for Living"?',
      options: ['R. C. Hutchinson', 'Satyajit Ray', 'Joan Lexau', 'Toni Morrison'],
      correctAnswer: 0,
      explanation: '"The Pace for Living" is written by the British novelist R. C. Hutchinson.'
    }
  ]
};

const INITIAL_LEADERBOARD = [
  { rank: 1, name: 'रोहित कुमार', district: 'पटना', score: 98, total: 100, percent: '98%' },
  { rank: 2, name: 'नेहा कुमारी', district: 'गया', score: 96, total: 100, percent: '96%' },
  { rank: 3, name: 'अमित कुमार सिंह', district: 'मुजफ्फरपुर', score: 94, total: 100, percent: '94%' },
  { rank: 4, name: 'पूजा राज', district: 'भागलपुर', score: 92, total: 100, percent: '92%' },
  { rank: 5, name: 'विकास यादव', district: 'दरभंगा', score: 90, total: 100, percent: '90%' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('home'); 
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('eay_user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [questions, setQuestions] = useState(() => {
    const saved = localStorage.getItem('eay_questions');
    return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
  });

  const [activeSubject, setActiveSubject] = useState(null);
  const [testState, setTestState] = useState(null); 
  const [userAnswers, setUserAnswers] = useState({});
  const [markedForReview, setMarkedForReview] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [testResult, setTestResult] = useState(null);
  
  const [testHistory, setTestHistory] = useState(() => {
    const saved = localStorage.getItem('eay_history');
    return saved ? JSON.parse(saved) : [];
  });

  const [adminPin, setAdminPin] = useState('');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [newQSubject, setNewQSubject] = useState('sci');
  const [newQText, setNewQText] = useState('');
  const [newQOptions, setNewQOptions] = useState(['', '', '', '']);
  const [newQCorrect, setNewQCorrect] = useState(0);
  const [newQExplanation, setNewQExplanation] = useState('');

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('eay_questions', JSON.stringify(questions));
  }, [questions]);

  useEffect(() => {
    localStorage.setItem('eay_history', JSON.stringify(testHistory));
  }, [testHistory]);

  useEffect(() => {
    let timer;
    if (testState === 'active' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleFinalSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [testState, timeLeft]);

  const handleStudentLogin = (e) => {
    e.preventDefault();
    const name = e.target.studentName.value.trim();
    const district = e.target.studentDistrict.value.trim();
    const rollNo = e.target.studentRoll.value.trim();
    
    if (name && district) {
      const newUser = { name, district, rollNo: rollNo || 'N/A', id: Date.now() };
      setUser(newUser);
      localStorage.setItem('eay_user', JSON.stringify(newUser));
    }
  };

  const startTest = (subjId) => {
    if (!user) {
      setActiveTab('login');
      return;
    }
    const subjQuestions = questions[subjId] || [];
    if (subjQuestions.length === 0) {
      alert('इस विषय में अभी कोई प्रश्न उपलब्ध नहीं हैं।');
      return;
    }
    setActiveSubject(subjId);
    setTestState('active');
    setUserAnswers({});
    setMarkedForReview({});
    setCurrentQuestionIdx(0);
    setTimeLeft(subjQuestions.length * 60); 
    setTestResult(null);
  };

  const handleAnswerSelect = (optIdx) => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestionIdx]: optIdx,
    }));
  };

  const toggleMarkForReview = () => {
    setMarkedForReview((prev) => ({
      ...prev,
      [currentQuestionIdx]: !prev[currentQuestionIdx],
    }));
  };

  const handleFinalSubmit = () => {
    if (!activeSubject) return;
    const subjQuestions = questions[activeSubject] || [];
    let correct = 0;
    let incorrect = 0;
    let unattempted = 0;

    subjQuestions.forEach((q, idx) => {
      const selected = userAnswers[idx];
      if (selected === undefined) {
        unattempted++;
      } else if (selected === q.correctAnswer) {
        correct++;
      } else {
        incorrect++;
      }
    });

    const totalMarks = subjQuestions.length;
    const obtainedMarks = correct;
    const percentage = ((obtainedMarks / totalMarks) * 100).toFixed(1);

    const result = {
      id: Date.now(),
      date: new Date().toLocaleDateString('hi-IN'),
      subjectId: activeSubject,
      subjectName: INITIAL_SUBJECTS.find(s => s.id === activeSubject)?.name || activeSubject,
      totalQuestions: totalMarks,
      correct,
      incorrect,
      unattempted,
      obtainedMarks,
      percentage,
      userAnswers,
    };

    setTestResult(result);
    setTestHistory((prev) => [result, ...prev]);
    setTestState('completed');
  };

  const handleAdminAuth = (e) => {
    e.preventDefault();
    if (adminPin === '123456') {
      setIsAdminLoggedIn(true);
    } else {
      alert('गलत पिन! सही एडमिन पिन 123456 है।');
    }
  };

  const handleAddQuestion = (e) => {
    e.preventDefault();
    if (!newQText || newQOptions.some(o => !o.trim())) {
      alert('कृपया प्रश्न और चारों विकल्प भरें!');
      return;
    }

    const newObj = {
      id: `${newQSubject}_${Date.now()}`,
      question: newQText,
      options: newQOptions,
      correctAnswer: parseInt(newQCorrect),
      explanation: newQExplanation || 'कोई विस्तृत उत्तर उपलब्ध नहीं है।'
    };

    setQuestions((prev) => ({
      ...prev,
      [newQSubject]: [...(prev[newQSubject] || []), newObj]
    }));

    setNewQText('');
    setNewQOptions(['', '', '', '']);
    setNewQExplanation('');
    alert('प्रश्न सफलतापूर्वक जोड़ दिया गया है!');
  };

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      
      {/* Top Header */}
      <header className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-800 text-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="w-10 h-10 bg-amber-400 text-blue-950 font-black rounded-lg flex items-center justify-center text-xl shadow-lg border-2 border-amber-300">
              EY
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-wide bg-clip-text text-transparent bg-gradient-to-r from-amber-300 via-white to-amber-200">
                ER ARPIT YADAV
              </h1>
              <p className="text-xs text-blue-200 font-medium">MATRIC PORTAL • बिहार बोर्ड कक्षा 10वीं</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-1 font-medium text-sm">
            <button 
              onClick={() => setActiveTab('home')}
              className={`px-3 py-2 rounded-md transition ${activeTab === 'home' ? 'bg-blue-800 text-amber-300 font-semibold' : 'hover:bg-blue-800/60 text-slate-200'}`}
            >
              होम (Home)
            </button>
            <button 
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-2 rounded-md transition ${activeTab === 'leaderboard' ? 'bg-blue-800 text-amber-300 font-semibold' : 'hover:bg-blue-800/60 text-slate-200'}`}
            >
              टॉपर्स लीडरबोर्ड
            </button>
            {user && (
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`px-3 py-2 rounded-md transition ${activeTab === 'dashboard' ? 'bg-blue-800 text-amber-300 font-semibold' : 'hover:bg-blue-800/60 text-slate-200'}`}
              >
                डैशबोर्ड
              </button>
            )}
            <button 
              onClick={() => setActiveTab('mobile-guide')}
              className={`px-3 py-2 rounded-md transition ${activeTab === 'mobile-guide' ? 'bg-blue-800 text-amber-300 font-semibold' : 'hover:bg-blue-800/60 text-slate-200'}`}
            >
              📱 मोबाइल होस्टिंग गाइड
            </button>
            <button 
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-md transition ${activeTab === 'admin' ? 'bg-blue-800 text-amber-300 font-semibold' : 'hover:bg-blue-800/60 text-slate-200'}`}
            >
              शिक्षक/एडमिन
            </button>
          </nav>

          <div className="hidden md:flex items-center space-x-3">
            {user ? (
              <div className="flex items-center space-x-2 bg-blue-950/60 px-3 py-1.5 rounded-full border border-blue-700/50">
                <User className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-semibold text-slate-100">{user.name}</span>
                <button 
                  onClick={() => { setUser(null); localStorage.removeItem('eay_user'); }}
                  className="text-xs text-rose-300 hover:text-rose-100 ml-2"
                  title="लॉगआउट"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setActiveTab('login')}
                className="bg-amber-400 hover:bg-amber-300 text-blue-950 px-4 py-1.5 rounded-full font-bold text-xs shadow transition flex items-center space-x-1"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>लॉगिन / रजिस्ट्रेशन</span>
              </button>
            )}
          </div>

          <button 
            className="md:hidden text-white p-1"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-blue-950 border-t border-blue-800 px-4 py-3 space-y-2 text-sm">
            <button 
              onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 rounded hover:bg-blue-900"
            >
              होम (Home)
            </button>
            <button 
              onClick={() => { setActiveTab('leaderboard'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 rounded hover:bg-blue-900"
            >
              टॉपर्स लीडरबोर्ड
            </button>
            {user && (
              <button 
                onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
                className="block w-full text-left py-2 px-3 rounded hover:bg-blue-900"
              >
                स्टूडेंट डैशबोर्ड
              </button>
            )}
            <button 
              onClick={() => { setActiveTab('mobile-guide'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 rounded hover:bg-blue-900 text-amber-300 font-medium"
            >
              📱 मोबाइल से वेबसाइट बनाएं & होस्ट करें
            </button>
            <button 
              onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
              className="block w-full text-left py-2 px-3 rounded hover:bg-blue-900"
            >
              शिक्षक/एडमिन
            </button>
            <div className="pt-2 border-t border-blue-800">
              {user ? (
                <div className="flex items-center justify-between py-1">
                  <span className="text-amber-300 font-semibold">{user.name} ({user.district})</span>
                  <button 
                    onClick={() => { setUser(null); localStorage.removeItem('eay_user'); setMobileMenuOpen(false); }}
                    className="text-xs text-rose-300"
                  >
                    लॉगआउट
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => { setActiveTab('login'); setMobileMenuOpen(false); }}
                  className="w-full bg-amber-400 text-blue-950 font-bold py-2 rounded text-center"
                >
                  लॉगिन / रजिस्ट्रेशन करें
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6">
        
        {/* Test Active View */}
        {testState === 'active' && activeSubject && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl shadow-md border border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-1 rounded">
                  {INITIAL_SUBJECTS.find(s => s.id === activeSubject)?.name}
                </span>
                <h2 className="text-lg font-bold mt-1">बिहार बोर्ड मैट्रिक वस्तुनिष्ठ (MCQ) परीक्षा</h2>
              </div>
              <div className="flex items-center space-x-2 bg-rose-50 border border-rose-200 text-rose-700 px-4 py-2 rounded-lg font-mono font-bold text-lg">
                <Clock className="w-5 h-5 animate-pulse text-rose-600" />
                <span>{formatTime(timeLeft)}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-md border border-slate-200 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xs font-semibold text-slate-500 uppercase">
                      प्रश्न {currentQuestionIdx + 1} / {questions[activeSubject]?.length}
                    </span>
                    <button 
                      onClick={toggleMarkForReview}
                      className={`text-xs px-3 py-1 rounded-full font-medium border transition ${
                        markedForReview[currentQuestionIdx] 
                          ? 'bg-amber-100 text-amber-800 border-amber-300' 
                          : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {markedForReview[currentQuestionIdx] ? '★ रिव्यू के लिए चिन्हित' : '☆ रिव्यू के लिए चिन्हित करें'}
                    </button>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 mb-6">
                    {questions[activeSubject]?.[currentQuestionIdx]?.question}
                  </h3>

                  <div className="space-y-3">
                    {questions[activeSubject]?.[currentQuestionIdx]?.options.map((opt, oIdx) => {
                      const isSelected = userAnswers[currentQuestionIdx] === oIdx;
                      return (
                        <button
                          key={oIdx}
                          onClick={() => handleAnswerSelect(oIdx)}
                          className={`w-full text-left p-4 rounded-lg border-2 transition flex items-center justify-between ${
                            isSelected 
                              ? 'bg-blue-50 border-blue-600 text-blue-900 font-medium shadow-sm' 
                              : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                              isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span>{opt}</span>
                          </div>
                          {isSelected && <Check className="w-5 h-5 text-blue-600" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-6 border-t mt-6">
                  <button
                    disabled={currentQuestionIdx === 0}
                    onClick={() => setCurrentQuestionIdx(prev => prev - 1)}
                    className="px-4 py-2 border border-slate-300 rounded-lg font-medium text-sm disabled:opacity-40 flex items-center space-x-1"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>पिछला</span>
                  </button>

                  {currentQuestionIdx < (questions[activeSubject]?.length - 1) ? (
                    <button
                      onClick={() => setCurrentQuestionIdx(prev => prev + 1)}
                      className="px-5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-medium text-sm rounded-lg flex items-center space-x-1 shadow"
                    >
                      <span>अगला</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={handleFinalSubmit}
                      className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-lg shadow-md"
                    >
                      सबमिट करें (Submit)
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-white p-5 rounded-xl shadow-md border border-slate-200 space-y-4">
                <h4 className="font-bold text-sm text-slate-700 border-b pb-2">प्रश्न नेविगेटर palette</h4>
                <div className="grid grid-cols-5 gap-2">
                  {questions[activeSubject]?.map((_, idx) => {
                    const isAns = userAnswers[idx] !== undefined;
                    const isM = markedForReview[idx];
                    const isCurr = currentQuestionIdx === idx;

                    let bgClass = 'bg-slate-100 text-slate-700 border-slate-200';
                    if (isCurr) bgClass = 'ring-2 ring-blue-600 font-bold bg-blue-100 text-blue-900 border-blue-400';
                    else if (isM) bgClass = 'bg-amber-400 text-amber-950 border-amber-500 font-bold';
                    else if (isAns) bgClass = 'bg-emerald-500 text-white font-bold';

                    return (
                      <button
                        key={idx}
                        onClick={() => setCurrentQuestionIdx(idx)}
                        className={`h-10 rounded-lg text-sm border flex items-center justify-center transition ${bgClass}`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>

                <div className="pt-3 border-t text-xs space-y-2 text-slate-600">
                  <div className="flex items-center space-x-2">
                    <span className="w-3.5 h-3.5 bg-emerald-500 rounded-sm"></span>
                    <span>उत्तर दे दिया (Answered)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-3.5 h-3.5 bg-amber-400 rounded-sm"></span>
                    <span>रिव्यू के लिए चिन्हित (Marked)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="w-3.5 h-3.5 bg-slate-100 border border-slate-300 rounded-sm"></span>
                    <span>उत्तर नहीं दिया (Unanswered)</span>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <button
                    onClick={handleFinalSubmit}
                    className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-sm shadow transition"
                  >
                    टेस्ट समाप्त एवं जमा करें
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Test Result View */}
        {testState === 'completed' && testResult && (
          <div className="space-y-6 max-w-4xl mx-auto">
            
            <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 text-center space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <Trophy className="w-10 h-10" />
              </div>
              <div>
                <h2 className="text-2xl font-black text-slate-900">बधाई हो, {user?.name || 'विद्यार्थी'}!</h2>
                <p className="text-sm text-slate-500">आपका टेस्ट सफलतापूर्व जमा कर लिया गया है।</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
                <div className="p-3 bg-blue-50 rounded-xl border border-blue-100">
                  <p className="text-xs text-blue-600 font-semibold">कुल अंक</p>
                  <p className="text-2xl font-black text-blue-900">{testResult.obtainedMarks} / {testResult.totalQuestions}</p>
                </div>
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <p className="text-xs text-emerald-600 font-semibold">प्रतिशत (%)</p>
                  <p className="text-2xl font-black text-emerald-900">{testResult.percentage}%</p>
                </div>
                <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100">
                  <p className="text-xs text-indigo-600 font-semibold">सही उत्तर</p>
                  <p className="text-2xl font-black text-indigo-900">{testResult.correct}</p>
                </div>
                <div className="p-3 bg-rose-50 rounded-xl border border-rose-100">
                  <p className="text-xs text-rose-600 font-semibold">गलत उत्तर</p>
                  <p className="text-2xl font-black text-rose-900">{testResult.incorrect}</p>
                </div>
              </div>

              <div className="flex justify-center space-x-3 pt-2">
                <button
                  onClick={() => setTestState(null)}
                  className="bg-blue-700 hover:bg-blue-800 text-white font-bold px-6 py-2 rounded-lg text-sm shadow flex items-center space-x-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>दूसरा टेस्ट दें</span>
                </button>
              </div>
            </div>

            {/* Detailed Solutions Section */}
            <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6">
              <h3 className="text-lg font-bold text-slate-900 border-b pb-3 flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                <span>विस्तृत उत्तर एवं व्याख्या (Detailed Solutions)</span>
              </h3>

              <div className="space-y-6">
                {questions[testResult.subjectId]?.map((q, idx) => {
                  const userAns = testResult.userAnswers[idx];
                  const isCorrect = userAns === q.correctAnswer;
                  const isSkipped = userAns === undefined;

                  return (
                    <div key={idx} className="p-4 rounded-xl border bg-slate-50 space-y-3">
                      <div className="flex items-start justify-between">
                        <h4 className="font-bold text-slate-900 text-base">
                          {idx + 1}. {q.question}
                        </h4>
                        {isCorrect && (
                          <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full flex items-center space-x-1">
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>सही</span>
                          </span>
                        )}
                        {!isCorrect && !isSkipped && (
                          <span className="bg-rose-100 text-rose-800 text-xs font-bold px-2.5 py-1 rounded-full flex items-center space-x-1">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>गलत</span>
                          </span>
                        )}
                        {isSkipped && (
                          <span className="bg-slate-200 text-slate-700 text-xs font-bold px-2.5 py-1 rounded-full">
                            अप्रयासित
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm pt-2">
                        {q.options.map((opt, oIdx) => {
                          let optStyle = 'bg-white border-slate-200 text-slate-700';
                          if (oIdx === q.correctAnswer) {
                            optStyle = 'bg-emerald-100 border-emerald-400 text-emerald-950 font-semibold';
                          } else if (userAns === oIdx && !isCorrect) {
                            optStyle = 'bg-rose-100 border-rose-400 text-rose-950 font-semibold';
                          }

                          return (
                            <div key={oIdx} className={`p-2.5 rounded-lg border text-xs md:text-sm ${optStyle}`}>
                              {String.fromCharCode(65 + oIdx)}. {opt}
                            </div>
                          );
                        })}
                      </div>

                      <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs md:text-sm text-blue-900">
                        <p className="font-bold text-blue-950 mb-1">💡 समाधान / व्याख्या:</p>
                        <p>{q.explanation}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* Normal Tabs (Home, Leaderboard, Dashboard, Guide, Admin) */}
        {!testState && activeTab === 'home' && (
          <div className="space-y-8">
            
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-800 rounded-2xl p-6 md:p-10 text-white shadow-xl relative overflow-hidden">
              <div className="relative z-10 space-y-4 max-w-2xl">
                <span className="bg-amber-400 text-blue-950 font-bold text-xs px-3 py-1 rounded-full uppercase tracking-wider">
                  बिहार बोर्ड मैट्रिक परीक्षा 2025-2026
                </span>
                <h2 className="text-2xl md:text-4xl font-black leading-tight">
                  मैट्रिक परीक्षा की तैयारी करें नंबर 1 मॉडल पेपर और ऑनलाइन मॉक टेस्ट के साथ!
                </h2>
                <p className="text-blue-100 text-sm md:text-base">
                  सभी मुख्य विषयों के लिए नए सिलेबस पर आधारित वस्तुनिष्ठ (MCQ) प्रश्न। परीक्षा जैसे टाइमर और तुरंत परिणाम के साथ अभ्यास करें।
                </p>
                <div className="pt-2 flex flex-wrap gap-3">
                  {!user && (
                    <button 
                      onClick={() => setActiveTab('login')}
                      className="bg-amber-400 hover:bg-amber-300 text-blue-950 font-bold px-6 py-2.5 rounded-xl text-sm shadow-md transition"
                    >
                      निःशुल्क पंजीयन करें
                    </button>
                  )}
                  <button 
                    onClick={() => setActiveTab('leaderboard')}
                    className="bg-blue-800/80 hover:bg-blue-800 text-white border border-blue-600 font-medium px-5 py-2.5 rounded-xl text-sm transition"
                  >
                    🏆 टॉपर्स सूची देखें
                  </button>
                </div>
              </div>
            </div>

            {/* Subjects Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">विषय चुनें और मॉक टेस्ट शुरू करें</h3>
                  <p className="text-xs text-slate-500">बिहार बोर्ड क्लास 10वीं के सभी विषय</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {INITIAL_SUBJECTS.map((sub) => {
                  const qCount = questions[sub.id]?.length || 0;

                  return (
                    <div 
                      key={sub.id} 
                      className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 hover:shadow-md transition flex flex-col justify-between space-y-4 group"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-3xl p-2 bg-slate-100 rounded-xl">{sub.icon}</span>
                          <div>
                            <h4 className="font-bold text-slate-900 group-hover:text-blue-700 transition">{sub.name}</h4>
                            <p className="text-xs text-slate-500">{qCount} उपलब्ध वस्तुनिष्ठ प्रश्न</p>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-500">समय: {qCount * 1} मिनट</span>
                        <button
                          onClick={() => startTest(sub.id)}
                          className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg font-bold text-xs shadow flex items-center space-x-1"
                        >
                          <span>मॉक टेस्ट दें</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* Student Login / Register Tab */}
        {!testState && activeTab === 'login' && (
          <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-200 space-y-6">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center mx-auto font-black text-xl">
                EY
              </div>
              <h2 className="text-2xl font-bold text-slate-900">छात्र लॉगिन / पंजीयन</h2>
              <p className="text-xs text-slate-500">बिहार बोर्ड परीक्षा परिणाम और स्कोरकार्ड सुरक्षित रखने के लिए दर्ज करें</p>
            </div>

            <form onSubmit={handleStudentLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">पूरा नाम (Student Full Name) *</label>
                <input 
                  type="text" 
                  name="studentName"
                  required
                  placeholder="उदा. राहुल कुमार"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">जिला (District) *</label>
                <input 
                  type="text" 
                  name="studentDistrict"
                  required
                  placeholder="उदा. पटना, गया, मुजफ्फरपुर"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">रोल नंबर / कोड (ऐच्छिक)</label>
                <input 
                  type="text" 
                  name="studentRoll"
                  placeholder="उदा. 2400101"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 text-sm focus:ring-2 focus:ring-blue-600 outline-none"
                />
              </div>

              <button 
                type="submit"
                onClick={() => setActiveTab('home')}
                className="w-full bg-blue-700 hover:bg-blue-800 text-white font-bold py-3 rounded-lg text-sm shadow transition"
              >
                प्रोफ़ाइल सेव करें & टेस्ट दें
              </button>
            </form>
          </div>
        )}

        {/* Leaderboard Tab */}
        {!testState && activeTab === 'leaderboard' && (
          <div className="max-w-4xl mx-auto bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6">
            <div className="flex items-center space-x-3 border-b pb-4">
              <Trophy className="w-8 h-8 text-amber-500" />
              <div>
                <h2 className="text-xl font-bold text-slate-900">बिहार बोर्ड मैट्रिक - राज्यस्तरीय टॉपर्स लीडरबोर्ड</h2>
                <p className="text-xs text-slate-500">ऑनलाइन मॉक टेस्ट में सर्वाधिक अंक प्राप्त करने वाले छात्र</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b">
                    <th className="p-3 font-bold">रैंक</th>
                    <th className="p-3 font-bold">विद्यार्थी का नाम</th>
                    <th className="p-3 font-bold">जिला</th>
                    <th className="p-3 font-bold">प्राप्तांक</th>
                    <th className="p-3 font-bold">प्रतिशत</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {INITIAL_LEADERBOARD.map((item) => (
                    <tr key={item.rank} className="hover:bg-slate-50">
                      <td className="p-3">
                        <span className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                          item.rank === 1 ? 'bg-amber-400 text-amber-950' : 
                          item.rank === 2 ? 'bg-slate-300 text-slate-900' : 
                          item.rank === 3 ? 'bg-amber-700 text-white' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {item.rank}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-slate-900">{item.name}</td>
                      <td className="p-3 text-slate-600">{item.district}</td>
                      <td className="p-3 font-semibold text-blue-800">{item.score} / {item.total}</td>
                      <td className="p-3 font-bold text-emerald-600">{item.percent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Dashboard Tab */}
        {!testState && activeTab === 'dashboard' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 bg-blue-700 text-white font-bold rounded-full flex items-center justify-center text-xl shadow">
                  {user?.name?.[0] || 'U'}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{user?.name}</h2>
                  <p className="text-xs text-slate-500">जिला: {user?.district} • रोल नंबर: {user?.rollNo}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-4">
              <h3 className="font-bold text-slate-900 border-b pb-2">आपके द्वारा दिए गए मॉक टेस्ट का विवरण</h3>

              {testHistory.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-sm">
                  आपने अभी तक कोई मॉक टेस्ट नहीं दिया है। 
                  <br />
                  <button onClick={() => setActiveTab('home')} className="mt-2 text-blue-700 font-bold underline">
                    अभी पहला टेस्ट शुरू करें
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {testHistory.map((item) => (
                    <div key={item.id} className="p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 bg-slate-50">
                      <div>
                        <span className="text-xs font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                          {item.subjectName}
                        </span>
                        <p className="text-xs text-slate-500 mt-1">दिनांक: {item.date}</p>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-lg font-bold text-slate-900">{item.obtainedMarks} / {item.totalQuestions}</p>
                          <p className="text-xs font-bold text-emerald-600">{item.percentage}% अंक</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Mobile Deployment Guide Tab */}
        {!testState && activeTab === 'mobile-guide' && (
          <div className="max-w-4xl mx-auto bg-white p-6 md:p-8 rounded-2xl shadow-md border border-slate-200 space-y-6">
            <div className="flex items-center space-x-3 border-b pb-4">
              <Smartphone className="w-8 h-8 text-blue-600" />
              <div>
                <h2 className="text-xl font-bold text-slate-900">मोबाइल से वेबसाइट फ्री में कैसे होस्ट करें?</h2>
                <p className="text-xs text-slate-500">बिना कंप्यूटर के 100% फ्री में ऑनलाइन लाइव करें</p>
              </div>
            </div>

            <div className="space-y-4 text-sm text-slate-700">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl space-y-2">
                <h3 className="font-bold text-blue-900 flex items-center space-x-2">
                  <span>तरीका 1: GitHub Mobile App + Netlify (बिना कंप्यूटर)</span>
                </h3>
                <ol className="list-decimal list-inside space-y-2 text-xs md:text-sm pl-1">
                  <li>अपने मोबाइल ब्राउजर में <strong>GitHub.com</strong> खोलें और फ्री अकाउंट बनाएं।</li>
                  <li>"New Repository" पर क्लिक करके नाम <code>er-arpit-yadav-test</code> रखें।</li>
                  <li>यह पूरा React कोड ZIP डाउनलोड करें और फ़ाइलें GitHub में अपलोड करें।</li>
                  <li>अब <strong>Netlify.com</strong> पर जाएं और अपने GitHub अकाउंट से लॉगिन करें।</li>
                  <li>अपनी रिपॉजिटरी चुनें - Netlify आपकी वेबसाइट को 1 मिनट में निःशुल्क लाइव कर देगा!</li>
                </ol>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                <h3 className="font-bold text-emerald-900">तरीका 2: Vercel Mobile Browser Hosting</h3>
                <ol className="list-decimal list-inside space-y-2 text-xs md:text-sm pl-1">
                  <li><strong>Vercel.com</strong> पर मोबाइल में लॉगिन करें।</li>
                  <li>Import Project में अपना कोड जोड़ें।</li>
                  <li>Build Command में <code>npm run build</code> और Output directory में <code>dist</code> रहने दें।</li>
                  <li>Deploy पर क्लिक करते ही आपको आपकी वेबसाइट का फ्री लिंक (URL) मिल जाएगा।</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Admin Dashboard Tab */}
        {!testState && activeTab === 'admin' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {!isAdminLoggedIn ? (
              <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-slate-200 space-y-4">
                <div className="text-center space-y-2">
                  <Key className="w-10 h-10 text-amber-500 mx-auto" />
                  <h2 className="text-xl font-bold">शिक्षक / एडमिन लॉगिन</h2>
                  <p className="text-xs text-slate-500">नए प्रश्न और मॉडल सेट जोड़ने के लिए पिन दर्ज करें</p>
                </div>

                <form onSubmit={handleAdminAuth} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">एडमिन सुरक्षा पिन (Default Pin: 123456)</label>
                    <input 
                      type="password"
                      value={adminPin}
                      onChange={(e) => setAdminPin(e.target.value)}
                      placeholder="******"
                      className="w-full px-4 py-2 rounded-lg border border-slate-300 text-center font-mono text-lg outline-none"
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full bg-blue-700 hover:bg-blue-800 text-white font-bold py-2.5 rounded-lg text-sm"
                  >
                    लॉगिन करें
                  </button>
                </form>
              </div>
            ) : (
              <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-6">
                <div className="flex justify-between items-center border-b pb-4">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900">शिक्षक डैशबोर्ड - प्रश्न जोड़ें</h2>
                    <p className="text-xs text-slate-500">बिहार बोर्ड परीक्षा के लिए नए वस्तुनिष्ठ प्रश्न प्रविष्ट करें</p>
                  </div>
                  <button 
                    onClick={() => setIsAdminLoggedIn(false)}
                    className="text-xs text-rose-600 border border-rose-200 px-3 py-1.5 rounded-lg font-bold"
                  >
                    एडमिन से बाहर निकलें
                  </button>
                </div>

                <form onSubmit={handleAddQuestion} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">विषय चुनें</label>
                    <select 
                      value={newQSubject}
                      onChange={(e) => setNewQSubject(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                    >
                      {INITIAL_SUBJECTS.map((s) => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">प्रश्न दर्ज करें</label>
                    <textarea 
                      value={newQText}
                      onChange={(e) => setNewQText(e.target.value)}
                      rows="2"
                      placeholder="उदा. प्रकाश के अपवर्तन के कितने नियम हैं?"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm outline-none"
                    ></textarea>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {newQOptions.map((opt, idx) => (
                      <div key={idx}>
                        <label className="block text-xs font-bold text-slate-700 mb-1">विकल्प {String.fromCharCode(65 + idx)}</label>
                        <input 
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const updated = [...newQOptions];
                            updated[idx] = e.target.value;
                            setNewQOptions(updated);
                          }}
                          placeholder={`विकल्प ${idx + 1}`}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm outline-none"
                        />
                      </div>
                    ))}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">सही विकल्प चुनें</label>
                    <select 
                      value={newQCorrect}
                      onChange={(e) => setNewQCorrect(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm"
                    >
                      <option value={0}>विकल्प A</option>
                      <option value={1}>विकल्प B</option>
                      <option value={2}>विकल्प C</option>
                      <option value={3}>विकल्प D</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">उत्तर की व्याख्या (Explanation)</label>
                    <textarea 
                      value={newQExplanation}
                      onChange={(e) => setNewQExplanation(e.target.value)}
                      rows="2"
                      placeholder="विद्यार्थियों के समझ के लिए विस्तृत उत्तर लिखें"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm outline-none"
                    ></textarea>
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg text-sm shadow"
                  >
                    प्रश्न जोड़ें (Save Question)
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-6 border-t border-slate-800 text-center text-xs mt-10">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-bold text-slate-200">ER ARPIT YADAV — MATRIC PORTAL</p>
          <p>बिहार बोर्ड (BSEB) कक्षा 10वीं के विद्यार्थियों के लिए समर्पित ऑनलाइन मॉक टेस्ट पोर्टल।</p>
          <p className="text-slate-500 pt-2">© 2026 ER ARPIT YADAV. सर्वाधिकार सुरक्षित।</p>
        </div>
      </footer>

    </div>
  );
}
